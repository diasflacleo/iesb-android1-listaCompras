package com.example.leonardo.listacompra

import java.io.FileDescriptor

public class Produto {

    var nome : String? = null
    var preco : Double? = null
    var descricao : String? = null
    //var imagem : String = ""


    constructor(nome: String, preco: Double, descricao: String){
            this.nome = nome
            this.preco = preco
            this.descricao = descricao
    }

    /*fun Produto(_nome: String, _descricao: String) {
        val nome: String = _nome
        get() = nome

        var descricao: String = _descricao
        get() = descricao
        set(value) {
            field = value
        }



    }*/


//------------------------------------------

    /*CONVERTE BASE64

    You can use the Base64 Android class:

            String encodedImage = Base64.encodeToString(byteArrayImage, Base64.DEFAULT);
    You'll have to convert your image into a byte array though. Here's an example:

    Bitmap bm = BitmapFactory.decodeFile("/path/to/image.jpg");
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    bm.compress(Bitmap.CompressFormat.JPEG, 100, baos); //bm is the bitmap object
    byte[] b = baos.toByteArray();
    * Update *

    If you're using an older SDK library (because you want it to work on phones with older versions of the OS) you won't have the Base64 class packaged in (since it just came out in API level 8 aka version 2.2).

    Check this article out for a work-around:

    http://androidcodemonkey.blogspot.com/2010/03/how-to-base64-encode-decode-android.html

    -----------------------------------------------------------------------------------------

    PHOTO NO ANDROID

    https://developer.android.com/training/camera/photobasics.html


    https://stackoverflow.com/questions/5991319/capture-image-from-camera-and-display-in-activity*/



    //--------------------------------

}